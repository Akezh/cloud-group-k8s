<footer>
  <div class="container">
    <p>
      © {new Date().getFullYear()} Speech to Text App. All rights reserved.
    </p>
  </div>
</footer>

<style>
  footer {
    background-color: white;
    padding: 1.5rem 0;
    text-align: center;
    color: var(--light-text);
    font-size: 0.875rem;
    border-top: 1px solid var(--border-color);
  }
</style>
